#pragma once
#include <iostream>


#include <Wbemidl.h>
#include <intrin.h>
#include <Windows.h>
#include <vector>

#include <comdef.h>
#include <unordered_map>

